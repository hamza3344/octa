﻿using System;
using System.Linq;

namespace octal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Decimal to octa" + decimaltoocta(1230));
            Console.WriteLine("OCta to decimal" + octtodecimal(2716.ToString()));
            Console.ReadLine();
        }
        static public string decimaltoocta(int number)
        {
            string octa = "";
            do
            {
                octa = octa + number % 8;
                number = number / 8;
            }
            while (number != 0);
            return new string(octa.ToCharArray().Reverse().ToArray());
        }
        static public double octtodecimal(string octa)
        {
            int i = 0;
            double val = 0;
            foreach(char s in octa.ToCharArray().Reverse())
            {
                val = val + (double.Parse(s.ToString()) * Math.Pow(8, i));
                i = i + 1;
            }
            return val;
        }
    }
}
